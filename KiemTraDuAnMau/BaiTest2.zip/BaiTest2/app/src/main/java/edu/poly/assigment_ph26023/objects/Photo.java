package edu.poly.assigment_ph26023.objects;

public class Photo {
    private int resouredId;

    public Photo(int resouredId) {
        this.resouredId = resouredId;
    }

    public int getResouredId() {
        return resouredId;
    }

    public void setResouredId(int resouredId) {
        this.resouredId = resouredId;
    }
}
