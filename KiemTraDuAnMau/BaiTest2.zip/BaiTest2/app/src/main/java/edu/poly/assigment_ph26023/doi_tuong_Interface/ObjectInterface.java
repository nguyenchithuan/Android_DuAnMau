package edu.poly.assigment_ph26023.doi_tuong_Interface;

public interface ObjectInterface {
    void onClickDelete(Object object);
    void onClickUpdate(Object object);
}
